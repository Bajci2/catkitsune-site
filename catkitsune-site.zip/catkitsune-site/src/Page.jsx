
import React from 'react'

export default function Page() {
  return (
    <main style={{padding:"40px", textAlign:"center"}}>
      <h1 style={{fontSize:"48px", fontWeight:"700"}}>CatKitSune</h1>
      <p style={{fontSize:"20px", marginTop:"10px"}}>Soon...</p>
    </main>
  )
}
